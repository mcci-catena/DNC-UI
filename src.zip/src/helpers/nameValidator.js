export function nameValidator(name) {
  if (!name || name.length <= 0) return "Name can't be empty."
  return ''
}
